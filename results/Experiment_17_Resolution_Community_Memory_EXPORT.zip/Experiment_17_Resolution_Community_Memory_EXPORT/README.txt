Experiment 17 - resolution kinetics, pro-resolving adjunct, community memory (see notebook markdown)
0_reduction: ExtModel reduces to periomemory 1.0.0 (trajectories, equilibria, Experiment_14 anchors).
17A_resolution_rate: A1 one gingivitis episode by rho; A2 therapy, window vs recovery, half-life, instant host,
  relapse ceiling (r = 1, 0.03); A3 calibrated rechallenge; A4 ratchet threshold and margin at T = 60.
17B_adjunct: B1 relapse by baseline and relapse ceiling with a 28-day clearance course (lambda, start), r = 1, 0.03;
  B2 21-day challenge with no course, concurrent course or early course.
17C_community_memory: C1 folds, therapy, retention, relapse ceiling for host x community memory; C2 critical
  plateau and rechallenge against naive and composition-matched naive sites; C2_decomposition host/community/interaction.
all_checks.csv: reduction checks, anchors and internal checks.
