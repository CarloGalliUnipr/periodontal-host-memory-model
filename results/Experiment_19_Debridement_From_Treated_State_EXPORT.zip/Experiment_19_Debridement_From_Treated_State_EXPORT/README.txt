Experiment 19 - Debridement at every recall from the treated state
Protocol of Experiment 15F (part F2) and Experiment 11: community removed at the start of every recall interval (T = 60),
plaque regrowing from 0 to the peak at the end of the interval; inflammation-free fraction = fraction of steps with H < 0.5.
Starts: treated = diseased equilibrium at baseline (0.20 reference, 0.25 tolerance-test), then debridement and 4 units
of perfect plaque control (pm.therapy); naive = H = M = A = 0 (the start of Experiments 15F and 11).
19A_reference_every_recall: F2_by_start.csv (both starts), F2_trend_by_start.csv, and F2_debridement_every_recall.csv
  (treated start, same columns as 15F F2; read by make_figures_JPR.py Figure 5C and make_figures_JPR_SI.py Figure S8A).
19B_sign_every_recall: debridement_by_sign_by_start.csv, trend_by_start.csv, and debridement_by_sign.csv (treated start,
  same columns as Experiment 11; read by make_figures_JPR_SI.py Figure S7B).
19C_convergence: memory hosts of 19A followed for 300 visits from both starts.
numbers_for_text.csv: first visit, mean of the last 10 visits, slope, min and max for every series.
all_checks.csv: anchors (Experiment 15F ledger values, full 15F F2 table if available, Experiment 11 curves) and checks.
