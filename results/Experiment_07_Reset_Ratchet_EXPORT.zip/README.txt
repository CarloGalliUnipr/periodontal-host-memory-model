Experiment 07 - Reset ratchet
=============================
Model M1 (memory coordinates A = ln(theta0/theta)) under periodic plaque regrowth
u = umax(1 - exp(-k tau)), tau = t mod T, comparator backbone of Exp 06B.
Hosts: slow memory (eps = 0.3 ... 0.003); instant adaptation (A = alpha H, same equilibria);
frozen memory (eps = 0) for the adiabatic reduction. Naive initial site (0, 0, 0).
Entrapped cycle: H never below 0.5 within it. Conversion: first cycle from which all
later cycles are entrapped. Plaque is reported as the peak reached before each reset.

Files
- parameters.json, software_versions.txt
- validation_vs_LSODA.csv                   RK4 vs LSODA on four cases
- fig07_01_example_ratchets(.jpg/_data.csv) theta at reset and peak H per cycle, T=60
- frozen_memory_cycle_response.npz          Theta(A) on (T, peak, A) grid; low-branch mask; A*, A_c
- averaged_map_thresholds.csv               eps->0 thresholds from A* = alpha Theta(A*)
- fig07_02_reduced_map_and_thresholds       reduced map (T=60) and thresholds vs kT
- fig07_03_phase_maps                       cycles to conversion over (kT, peak) per host
- conversion_thresholds_peak_plaque.csv     grid thresholds per host and T
- fig07_04_latency_scaling, latency_scaling_fits.csv
- fig07_05_debridement_relapse              relapse-free fraction per cycle with M reset
- monotonicity_checks.csv, summary.csv
