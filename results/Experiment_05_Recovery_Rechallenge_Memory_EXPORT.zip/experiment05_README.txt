
EXPERIMENT 05
RECOVERY–RECHALLENGE MEMORY
============================

PURPOSE
-------
Quantify how long the altered signal-response mapping produced
by prior conditioning persists after the conditioning stimulus
is removed.

MODEL
-----
Uses exactly the monostable parameter regime selected in
Experiment 04.

n       = 2.0
q       = 1.0
K_M     = 0.9
theta0  = 1.0
r       = 1.0
alpha   = 1.0
epsilon = 0.1

PROTOCOL
--------
baseline
    ->
conditioning
    ->
variable recovery interval
    ->
identical same-S rechallenge

Baseline/recovery forcing:
    u = 0.05

Conditioning forcing:
    u = 0.4

Physical rechallenge signal:
    S* = 0.675818127423361

Recovery intervals:
    [0.0, 0.5, 1.0, 2.0, 5.0, 10.0, 20.0, 40.0, 80.0, 160.0]

IMPORTANT
---------
The rechallenge is identical in PHYSICAL SIGNAL space.

Because:
    S = M + u

the required external forcing is dynamically adjusted during
the probe so that every rechallenge satisfies:

    S(t) = S*

This avoids confusing microbial-state differences with signal
differences.

PRIMARY MEMORY VARIABLES
------------------------
1. theta(T_recovery)

2. response mapping:
       F(S*, theta(T_recovery))

3. excess same-signal response relative to the fully recovered
   control

4. peak H-response amplitude

5. H-response AUC

6. theta-only matched-state response

APPARENT MEMORY HALF-LIFE
-------------------------
A model-free apparent half-life is calculated by interpolation
as the recovery time at which the excess memory measure falls
to 50% of its immediate post-conditioning value.

No exponential decay model is assumed.

This is important because H, M and theta remain dynamically
coupled, so the complete system need not recover as a single
exponential.

INTERPRETATION
--------------
If the same-signal response remains elevated after the
conditioning input has been removed, then the model exhibits
transient memory.

If the excess response progressively returns to zero as the
recovery interval increases, the model demonstrates reversible
history dependence with a measurable persistence timescale.

The phenomenological memory timescale should not be interpreted
as a biological periodontal time constant until the model has
been calibrated against experimental data.

DATA POLICY
-----------
All numerical results are saved as CSV.

Every figure has a matching source-data CSV.

All Experiment 05 outputs are isolated from Experiments 01-04.
