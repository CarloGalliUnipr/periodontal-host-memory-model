Experiment 10 - Daily home care nested in professional recall
=============================================================
Plaque u = u_a + u_r. Accessible u_a: regrowth 1/k_a = 2 units (~3 days), removed daily with
efficacy eta. Retained u_r: k_r = 0.05 (Exp 07), removed only at recall (T = 60 ~ 100 days).
Explicit daily drops vs day-averaged envelope (the Exp 07 assumption). Hosts: instant adaptation,
slow memory eps = 0.03, 0.01. Comparator backbone (Exp 06B).

Files
- parameters.json, software_versions.txt
- accessible_plaque_daily_cycle.csv            daily min / max / mean of accessible plaque by (U_a, eta)
- fig10_01_forcing                              one recall interval and a ten-day zoom
- validation_Ua0_vs_exp07.csv                   U_a = 0 reproduces Exp 07 thresholds
- fig10_02_example_trajectories                 H and theta, explicit vs averaged home care
- fig10_03_thresholds_and_latency, fig10_03_conversion_grid_data.csv,
  thresholds_explicit_vs_averaged.csv, latency_explicit_vs_averaged.csv
- fig10_04_debridement                          relapse-free fraction per recall with debridement
- checks_and_summary.csv
