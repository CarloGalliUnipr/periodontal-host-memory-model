Experiment 15 - Model revision (see notebook markdown for definitions)
15A_intrinsic_bistability: A1 therapy on the second set; A2 selection scan; A3 third set (n=q=4, K=0.7, th0=0.55,
  baseline 0.25): therapy and folds by alpha, window vs recovery, instant host, relapse ceiling, ratchet margin, rechallenge.
15B_intrinsic_sample: Latin-hypercube sample around the third set with one category per set; window ratios.
15C_calibrated_gingivitis: U* giving naive peak = TARGET_NAIVE_PEAK; rechallenge at U*; reversibility of naive challenges.
15D_matched_bleeding: rechallenge with naive sites matched on resting H (same plateau, same increment).
15E_safe_challenge: largest non-converting plateau by time since therapy and duration; stopping rules.
15F_repeated_instrumentation: single vs repeated instrumentation (F1); debridement at every recall at r = 1 and 0.03 (F2).
15G_weibull: folds, window ratio and rechallenge with Weibull response functions.
all_checks.csv: anchors reproducing Experiment_14_Revision and internal checks.
