Experiment 08 - History-dependent tipping window
================================================
Comparator backbone (Exp 06B), baseline plaque u_b = 0.20 (bistable window).
Protocol: history -> recovery at u_b (T_rec) -> challenge u_ch for D_ch -> settle 10/eps.
Histories: naive | resolved gingivitis (u = 0.45 for 5/eps) | treated disease (H, M healthy,
memory A retained from the high state). Hosts: slow memory eps = 0.1, 0.03, 0.01; instant
adaptation (same equilibria). Converted: H > 0.5 after settling.

Files
- parameters.json, software_versions.txt
- fig08_01_example_trajectories(.jpg/_data.csv)   same challenge, four histories/hosts
- fig08_02_critical_challenge                      critical amplitude vs challenge duration
- fig08_03_vulnerability_window                    critical challenge and V vs eps*T_rec
- memory_decay_after_treatment.csv                 A(T_rec) relative to its post-treatment value
- vulnerability_half_lives.csv, window_lengths.csv
- fig08_04_baseline_robustness                     u_b = 0.10 / 0.20 / 0.30, eps = 0.03
- consistency_checks.csv, summary.csv
