Experiment 13 - A pocket niche that partly resolves with inflammation
Comparator backbone. Niche term gamma*D*phi(H), phi = c + (1-c)H; c = 1 is the model of Exps 09-12, c = 0.5 and 0.25
let half or three quarters of the niche resolve with inflammation. gamma = 0.8, h_D = 0.8.
Files
- stage_boundaries.csv, fig13_01_stages                    D_irr(c), D_spont(c); equilibria at D = 0.3
- treatment_ladder_data.csv, treatment_ladder_Dmax.csv, fig13_02   hygiene / debridement / repeated debridement reach vs c
- post_therapy_maintenance_data.csv, post_therapy_thresholds.csv, fig13_03   re-entrapment peak after therapy vs D_res and c
- random_peaks_metrics.csv, fig13_04, fig13_05             Exp 12 peak sequences: spontaneous remission (no therapy), clustering,
                                                           burstiness (no therapy and treat on detection)
- checks.csv (includes exact reproduction of Exps 09 and 12 at c = 1), summary.csv, parameters.json
