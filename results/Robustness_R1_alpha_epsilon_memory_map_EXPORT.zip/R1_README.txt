
ROBUSTNESS R1
ALPHA-EPSILON MEMORY MAP
=========================

PURPOSE
-------
Test whether the history-dependent same-signal response found
in Experiments 4 and 5 is confined to the single original
(alpha, epsilon) choice or persists over a broader region of
adaptive-strength / adaptive-timescale space.

STRUCTURAL PARAMETERS
---------------------
n      = 2.0
q      = 1.0
K_M    = 0.9
theta0 = 1.0
r      = 1.0

These are the structural parameters selected automatically in
Experiment 4 for the monostable proof-of-principle regime.

PARAMETER SWEEP
---------------
alpha:
    0 to 3
    31 linearly spaced values

epsilon:
    0.01 to 1
    17 logarithmically spaced values

The ranges are exploratory computational ranges and are not
biologically calibrated periodontal parameter bounds.

PROTOCOL
--------
The physical protocol is held fixed across the full grid.

Low history forcing:
    u = 0.05

High conditioning forcing:
    u = 0.4

Baseline duration:
    150.0

History duration:
    200.0

Same physical probe signal:
    S* = 0.675818127423361

No pair-specific optimization of forcing, conditioning duration,
or probe signal is performed.

PRIMARY OUTCOME
---------------
Same-signal response difference:

    delta_R = F(S*, theta_B) - F(S*, theta_A)

where A and B have different previous forcing histories.

PRIMARY INTERPRETATION REGION
-----------------------------
The main robustness analysis is restricted to parameter pairs
that remain:

    1. structurally monostable across
       u = [0.02, 1.5]

and

    2. locally stable across that forcing interval.

Points outside this region are retained in the raw output but
are not used to claim memory without multistability.

MEMORY PERSISTENCE
------------------
After high-history conditioning, the model is returned to the
low forcing condition.

The response mapping at the identical physical signal S* is
evaluated at recovery times:

    [0.0, 0.25, 0.5, 1.0, 2.0, 5.0, 10.0, 20.0, 40.0, 80.0, 160.0, 320.0, 640.0, 1280.0]

Memory excess is defined relative to the exact low-forcing
equilibrium response mapping for that alpha:

    DeltaR_memory(T)
    =
    F(S*, theta(T))
    -
    F(S*, theta_low_equilibrium)

The apparent memory half-life is obtained by interpolation and
does not assume exponential decay.

IMPORTANT ACQUISITION/DECAY DISTINCTION
----------------------------------------
epsilon affects both:

    - how rapidly the adaptive state is acquired during the
      fixed-duration conditioning period;

and

    - how rapidly it is lost during recovery.

Therefore the notebook separately records the fraction of the
equilibrium response shift actually acquired during the
200-time-unit conditioning period.

NEGATIVE CONTROL
----------------
alpha = 0 should eliminate history-dependent threshold
adaptation.

The maximum numerical same-signal response difference in the
alpha = 0 row is saved explicitly as a validation metric.

MODEL-DEFINITION CAVEAT
-----------------------
The same provisional microbial response function is retained:

    G(H) = H^q / (H^q + K_M^q)

This robustness analysis tests parameter robustness within that
model definition.

Functional-form robustness is reserved for Robustness R3.

DATA POLICY
-----------
Every numerical result used in a table, figure, summary, or
interpretation is saved as machine-readable CSV.

Every figure has a companion figure-data CSV.

Checkpoint CSVs are written after every alpha row so the sweep
can resume after an interrupted Colab session.
