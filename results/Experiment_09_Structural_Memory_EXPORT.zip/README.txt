Experiment 09 - Structural memory (attachment loss)
===================================================
M1 (comparator backbone) plus D: dD/dt = delta*[H - 0.8]_+*(1 - D);
dM/dt = r(-M + G(H) + gamma*D), gamma = 0.8. Lemma: at fixed D the equilibria are those
of M1 with forcing u + gamma*D, giving D_irr = u_down/gamma and D_spont = u_up/gamma.
Hosts: slow memory eps = 0.1, 0.03, 0.01; instant adaptation (same equilibria).

Files
- parameters.json, software_versions.txt
- fig09_01_stage_structure, lemma_check.csv           equilibrium branches vs D; stage map; lemma check
- fig09_02_natural_history, natural_history_milestones.csv   D accumulation under maintenance (T = 60)
- fig09_03_treatment_ladder(_data.csv), treatment_ladder_Dmax.csv   four therapies x D x r x host
- fig09_04_debridement_reach                           largest D resolved by one debridement vs r and r/eps
- fig09_05_post_therapy_maintenance, post_therapy_thresholds.csv   tolerable peak plaque vs residual D and memory
- consistency_checks.csv, summary.csv
