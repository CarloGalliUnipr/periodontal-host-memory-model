Experiment 11 - Sign of adaptation (sensitizing, tolerizing, dose-dependent host)
Backbone n=q=4, K_M=0.5, theta0=0.6, r=1 (bistable for a in [-0.5, 0.5]). Memory target A*(H) = a*H - b*H^2.
Hosts: slow memory eps=0.03; instant (A = A*(H)).
Files
- equilibrium_windows.csv, fig11_01_equilibria             folds vs a; branches
- tipping_window_by_sign.csv, fig11_02                      critical challenge naive vs treated, by a and recovery time
- relapse_ceiling_by_sign.csv                               relapse without challenge after therapy
- periodic_thresholds_by_sign.csv, debridement_by_sign.csv, fig11_03   periodic forcing; debridement at every visit
- dose_dependent_host.csv, fig11_04                         trained-then-tolerized host: naive / gingivitis / treated
- checks.csv, summary.csv, parameters.json
