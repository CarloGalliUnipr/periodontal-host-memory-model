
ROBUSTNESS R2
MULTIVARIATE STRUCTURAL ROBUSTNESS
==================================

PURPOSE
-------
Test whether the history-dependent same-signal response
demonstrated in Experiments 4-5 and R1 survives simultaneous
perturbation of the model's structural and timescale
parameters.

SAMPLING DESIGN
---------------
A fixed-seed Latin-hypercube sample of 1000 parameter
sets was generated.

Seed:
    20261006

The sampled fractions are properties of this prespecified
computational sample and must NOT be interpreted as biological
probabilities.

PARAMETER RANGES
----------------
n:
    1.5 to 2.5

q:
    0.75 to 1.50

K_M:
    0.75 to 1.00

theta0:
    0.80 to 1.00

alpha:
    0.50 to 1.50

r:
    0.30 to 3.00
    log-uniform

epsilon:
    0.03 to 0.30
    log-uniform

REFERENCE MODEL
---------------
Experiment 4:

    n       = 2.0
    q       = 1.0
    K_M     = 0.9
    theta0  = 1.0
    alpha   = 1.0
    r       = 1.0
    epsilon = 0.1

STRUCTURAL CLASSIFICATION
-------------------------
Each sampled parameter set was classified over:

    u = [0.02, 1.5]

as structurally monostable or multistable using both:

    - equilibrium root counts;
    - fold detection.

Structurally monostable sets were then screened for local
stability using Jacobian eigenvalues.

PRIMARY MEMORY ANALYSIS
-----------------------
Only stable monostable models are used for the primary
"memory without multistability" robustness claim.

History A begins at the exact low-forcing equilibrium.

History B begins from the same equilibrium and receives:

    u = 0.4
    for 200.0 time units.

Both are evaluated at the same fixed physical signal:

    S* = 0.675818127423361

No parameter-specific probe signal or conditioning forcing is
optimized.

PHYSICAL PROBE ADMISSIBILITY
----------------------------
For the primary subset, the external forcing required to
generate S* at each history endpoint must remain nonnegative
and within the prevalidated positive forcing interval.

MEMORY MEASURE
--------------
Primary immediate memory:

    DeltaR =
        F(S*, theta_B)
        -
        F(S*, theta_A)

Recovery is measured after return to:

    u = 0.05

at times:

    [0.0, 1.0, 2.0, 5.0, 10.0, 20.0, 40.0, 80.0, 160.0, 320.0]

Because R1 revealed a small early post-removal overshoot in
some slow-adaptation cases, the apparent half-life in R2 is
measured relative to the maximum observed post-conditioning
memory value rather than necessarily the value at T=0.

INTERPRETATION
--------------
R2 asks whether adaptive memory is robust to simultaneous
parameter perturbation.

It does NOT estimate the probability that biological
periodontal systems exhibit memory.

MODEL-DEFINITION CAVEAT
-----------------------
The same provisional microbial response function is retained:

    G(H) =
    H^q / (H^q + K_M^q)

Thus R2 establishes parameter robustness within the current
functional architecture.

Functional-form robustness is reserved for R3.

DATA POLICY
-----------
All interpreted numerical outputs are saved as CSV.

Every figure has a companion figure-data CSV.

Checkpoint files allow interrupted Colab runs to resume
without regenerating completed samples.
