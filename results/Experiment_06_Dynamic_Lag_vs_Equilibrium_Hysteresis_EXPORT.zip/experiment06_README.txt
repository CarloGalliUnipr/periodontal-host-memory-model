
EXPERIMENT 06
DYNAMIC LAG VERSUS EQUILIBRIUM HYSTERESIS
==========================================

PRIMARY QUESTION
----------------
Can rate-dependent loops caused by finite adaptation speed be
distinguished from genuine equilibrium hysteresis?

CORE DIAGNOSTIC
---------------
For multiple ramp speeds:

    U_MIN -> U_MAX -> U_MIN

measure apparent forward and reverse switching points.

If the regime is monostable:

    apparent hysteresis width -> 0

as ramp speed -> 0.

If the equilibrium system is bistable:

    apparent hysteresis width

should approach the finite separation between its two
equilibrium folds.

REGIME A
--------
Monostable adaptive regime selected in Experiment 04.

Parameters:
{'n': 2.0, 'q': 1.0, 'K_M': 0.9, 'theta0': 1.0, 'r': 1.0, 'epsilon': 0.1}

alpha:
1.0

Any up/down loop in this regime is necessarily dynamic.

REGIME B
--------
Positive-forcing bistable adaptive comparator.

The comparator was NOT selected manually.

A predeclared parameter grid was screened and a candidate was
accepted only if:

    U_MIN < reverse fold < forward fold < U_MAX

with:

- one equilibrium at U_MIN;
- one equilibrium at U_MAX;
- three equilibria between the folds;
- stable / unstable / stable local stability pattern.

The passing candidate closest to the Experiment 01 reference
parameter set was chosen automatically.

Selected comparator:
{'n': 4.0, 'q': 4.0, 'K_M': 0.9, 'theta0': 0.8, 'r': 1.0, 'epsilon': 0.1}

Equilibrium forward fold:
0.46823922152771974

Equilibrium reverse fold:
0.06302047679206813

Equilibrium hysteresis width:
0.4052187447356516

RAMP RANGE
----------
U_MIN = 0.05
U_MAX = 0.8

Ramp durations:
[10.0, 25.0, 50.0, 100.0, 200.0, 400.0, 800.0]

Ramp speeds:
[0.075, 0.03, 0.015, 0.0075, 0.00375, 0.001875, 0.0009375]

PRIMARY SWITCHING METRIC
------------------------
Maximum absolute slope:

    max |dH/du|

on each upward and downward ramp leg.

A secondary H = 0.5 crossing metric is also saved.

LOOP AREAS
----------
For each ramp speed the areas between the upward and downward
branches are calculated for:

    H(u)
    M(u)
    theta(u)

INTERPRETATION
--------------
A loop seen at finite forcing speed is NOT sufficient evidence
of equilibrium hysteresis.

The relevant distinction is the slow-ramp limit:

MONOSTABLE:
    width -> 0

BISTABLE:
    width -> equilibrium fold separation > 0

The slow-rate linear extrapolation is exploratory only and is
not assumed to be a mechanistic law.

MODEL-DEFINITION NOTE
---------------------
The same provisional microbial response function is retained:

    G(H) = H^q / (H^q + K_M^q)

Changing this function later requires rerunning the model
experiments.

DATA POLICY
-----------
All numerical outputs are CSV.

Every JPEG has a figure-specific CSV.

Experiment 06 is stored separately from Experiments 01-05.
