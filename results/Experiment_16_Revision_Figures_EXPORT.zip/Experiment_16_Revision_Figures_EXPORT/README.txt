Experiment 16 - Revision figures
16A_second_set_defined_therapy: sign of adaptation on the second set with the defined therapy (window_by_alpha.csv:
  treated/naive and state-reset/naive critical challenge vs recovery; instant_host.csv; dose_dependent.csv;
  relapse_ceiling.csv; folds_by_alpha.csv; traces_alpha_m05.csv).
figures/: Figure3, Figure4, FigureS6, FigureS11, FigureS12, FigureS13 (complete) and FigureS15_EF (new panels E-F),
  each as PDF, 600-dpi PNG and per-panel CSV.
numbers_for_text.csv: values quoted in the revised text. Inputs in _inputs/ (Experiments 11, 14) and the Experiment 15 export.
