
ROBUSTNESS R3
FUNCTIONAL-FORM ROBUSTNESS
===========================

PURPOSE
-------
Test whether the principal history-dependent same-signal
response result depends specifically on Hill-function algebra.

FUNCTIONAL FORMS
----------------
Four prespecified host/microbial response combinations were
tested:

1. Hill F / Hill G
2. Hill F / Weibull G
3. Weibull F / Hill G
4. Weibull F / Weibull G

MATCHED WEIBULL FORM
--------------------
The alternative response function is:

    W(x; K, m)
    =
    1 - exp[-ln(2) * (x/K)^m]

with:

    m = p / (2 ln 2)

where p is the corresponding Hill exponent.

This construction gives:

    W(0) = 0
    W(K) = 0.5
    W(infinity) = 1

and matches the Hill function's local midpoint slope:

    W'(K) = p / (4K)

Thus Hill and Weibull curves share zero baseline, midpoint,
midpoint slope, and saturation, while differing in global
functional shape.

ADAPTATION LAW
--------------
The adaptive-threshold law is deliberately unchanged.

Therefore R3 tests RESPONSE-FUNCTION robustness rather than
adaptation-law robustness.

REFERENCE TEST
--------------
All four functional forms are first evaluated using the exact
Experiment 4 numerical parameter values:

{'n': 2.0, 'q': 1.0, 'K_M': 0.9, 'theta0': 1.0, 'alpha': 1.0, 'r': 1.0, 'epsilon': 0.1}

and the original protocol:

    U_LOW = 0.05
    U_HIGH = 0.4
    conditioning duration = 200.0
    physical probe S* = 0.675818127423361

PAIRED MULTIVARIATE TEST
------------------------
The exact 1,000 parameter vectors generated previously in R2
are reused.

No new parameter sample is generated.

Each parameter vector is therefore evaluated under the same
four alternative functional architectures.

PRIMARY ANALYSIS
----------------
For every functional form:

1. classify equilibrium geometry over
   u = [0.02, 1.5];

2. retain structurally monostable models;

3. require local equilibrium stability;

4. apply the exact same conditioning protocol;

5. require the same physical probe S* to be achievable using
   nonnegative forcing;

6. calculate same-signal response memory:

       DeltaR
       =
       F(S*, theta_B)
       -
       F(S*, theta_A)

7. quantify recovery and peak-based apparent half-life.

COMMON-SUBSET ANALYSIS
----------------------
A strict paired comparison is also performed using only
parameter vectors that remain:

    stable,
    monostable,
    and probe-admissible

under ALL FOUR functional forms.

This prevents differences in dynamical-regime eligibility from
confounding the cross-form comparison.

INTERPRETATION
--------------
If same-signal adaptive memory persists under the alternative
matched response functions, the result is not specific to Hill
algebra.

The fractions observed in the R2/R3 computational sample are
NOT biological probabilities.

MODEL SCOPE
-----------
R3 changes the static signal-response functions but retains:

    dtheta/dt
    =
    epsilon * theta *
    [ln(theta0/theta) - alpha H]

Thus R3 does not establish robustness to every possible
adaptation law.

DATA POLICY
-----------
All interpreted numerical results are saved as CSV.

Every JPEG has a companion source-data CSV.

All intermediate paired classifications and trajectories are
saved for reproducibility.
