14A - Simulated experimental-gingivitis rechallenge after therapy
rechallenge_reference.csv: one row per baseline x host x history x U x recovery time.
  peak_H, auc_H_days during the 21-day challenge; persistent = H > 0.5 after settling at baseline;
  reversed_by_plaque_control / reversed_by_debridement: outcome of u = 0 (and M -> 0) for the settling time.
  histories: naive (D = 0); treated_D0; treated_Dres (D = 0.10, above D_irr). Rows with no_challenge = True (U = baseline) show relapse without challenge. D fixed throughout.
rechallenge_single_state.csv: single-state set, conditioning u = 0.4 for 200 units, natural return to 0.05.
summary_peakH_U040.csv, summary_lowest_persistent_U.csv, summary_relapse_without_challenge.csv, figures fig14A_*.
