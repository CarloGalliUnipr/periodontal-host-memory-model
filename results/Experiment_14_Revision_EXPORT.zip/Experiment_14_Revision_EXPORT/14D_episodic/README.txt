14D - Episodic activity with activity-independent clustering measures
D1_original_conditions.csv: the eight Experiment 12 conditions with all measures.
D2_scan_common_draws.csv: mean peak scanned with common standard-normal draws.
D3_activity_matched.csv: each host rerun at the mean giving active fraction 0.1/0.2/0.3/0.5.
Measures: active fraction; lag-1 autocorrelation; P(active|active) - P(active|quiet); burstiness of quiet-run
lengths (s - m)/(s + m); quiet runs in first/last third; top-10% share; Gini of loss over active intervals.
per_site_loss_sequences.npz: per-site loss per interval for every condition.
