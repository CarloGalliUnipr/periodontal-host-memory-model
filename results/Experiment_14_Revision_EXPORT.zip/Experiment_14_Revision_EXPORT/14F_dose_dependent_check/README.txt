14F - Dose-dependent host (A* = H - 1.4 H^2, second set): conversion on a 0.01 grid of challenges.
Exp 11 bisection values: naive 0.358, treated 0.380 (ratio 1.06).
