14B - Post-therapy window with a model-defined therapy
B1_critical_vs_duration.csv: critical step challenge vs duration (recovery 0), reductions vs naive and vs instant host.
B2_window_vs_recovery.csv: critical challenge and V vs recovery (duration 2/eps); B2_half_lives_and_window_lengths.csv;
  B2_memory_decay_treated_protocol.csv: A after therapy relative to its pre-therapy value.
B3_recolonization_check.csv: naive/treated at r = 1 and r = 0.03.
B4_relapse_ceiling.csv (+ summary): lowest baseline above which treated sites relapse without challenge.
B5_plaque_control_sensitivity.csv: treated critical challenge vs length of post-debridement plaque control.
treated_protocol = diseased equilibrium at the baseline, M -> 0, u = 0 for T_PC = 4 units (~7 days), then baseline.
treated_reset = Experiment 08 definition (H, M healthy; A of the diseased state).
