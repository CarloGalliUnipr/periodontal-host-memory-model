14C - Ratchet with alternative criteria; latency vs reduced-map passage time
C1_grid.csv: per host, T, peak: conversion cycle (full entrapment), first recall with H > 0.5, first recall with H > 0.8.
C1_thresholds.csv: thresholds by each criterion; ratios to the static fold and to the instant host.
C2_latency_vs_passage.csv: cycles to conversion vs passage time s = int dA/(aTheta - A); ratios N eps T/s and N(1-e^-eps T)/s.
C2_exponent_near_threshold.csv: log-log slope within 2% of threshold.
C3_recolonization_check.csv: T = 60 thresholds at r = 1 and r = 0.03.
