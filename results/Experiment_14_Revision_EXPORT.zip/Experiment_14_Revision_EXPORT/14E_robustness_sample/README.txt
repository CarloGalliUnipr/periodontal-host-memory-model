14E - Robustness sample in the bistable regime
E_sample_results.csv: one row per set (set 0 = reference): folds, stage boundaries, whether bistability needs
  adaptation, window ratios (treated_protocol vs naive and vs instant, eps = 0.03, duration 2/eps), ratchet
  thresholds at T = 60 and the margin of the eps = 0.01 host over the instant host.
E_summary.csv: counts and median [10th, 90th percentile]. Ratchet thresholds use an 80-cycle follow-up,
  so thresholds of slow hosts very close to tolerance are slightly overestimated.
