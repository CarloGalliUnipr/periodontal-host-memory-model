Experiment 12 - Variable plaque and episodic disease activity
Comparator backbone with structural memory (gamma=0.8, h_D=0.8, delta=0.001). Plaque regrows (k=0.05) and is removed
every T=60; the peak of each interval is log-normal (mean, CV), same sequences for every host.
A: no therapy (plaque removal only). B: treat on detection (debridement M->0 at a recall if H>0.5 at the visit).
Hosts: instant; slow memory eps=0.03, 0.01. Active interval: attachment loss > 1e-4.
Files
- no_therapy_onset.csv, fig12_01_onset_no_therapy          onset times, conversion fraction, remissions
- treat_on_detection_metrics.csv, fig12_02_example_sites, fig12_03_burstiness   activity, clustering, burstiness, loss
- peak_sequences.npz, checks.csv, summary.csv, parameters.json
